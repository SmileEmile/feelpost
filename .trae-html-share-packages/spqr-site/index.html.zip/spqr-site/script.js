/* ============ SPQR site interactions ============ */

/* ---------- Laurel wreath (hero) ---------- */
(function buildWreath(){
  const svg = document.getElementById('wreath');
  if (!svg) return;

  const NS = 'http://www.w3.org/2000/svg';
  const cx = 210, cy = 214, R = 150;

  const defs = document.createElementNS(NS, 'defs');
  defs.innerHTML = `
    <linearGradient id="leafGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#f2dfae"/>
      <stop offset="55%" stop-color="#c6a15b"/>
      <stop offset="100%" stop-color="#8a6a2e"/>
    </linearGradient>
    <linearGradient id="stemGrad" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#d8bd82"/>
      <stop offset="100%" stop-color="#7c5f2a"/>
    </linearGradient>`;
  svg.appendChild(defs);

  const toXY = (deg, r) => {
    const rad = deg * Math.PI / 180;
    return [cx + Math.cos(rad) * r, cy + Math.sin(rad) * r];
  };

  let leafIndex = 0;

  [-1, 1].forEach((side) => {
    // side 1: right branch (bottom -> upper right); mirrored for left
    const start = side === 1 ? 84 : 96;
    const end = side === 1 ? -82 : 262;

    // stem path
    let d = '';
    for (let a = start; side === 1 ? a >= end : a <= end; a -= side * 2) {
      const [x, y] = toXY(a, R);
      d += (d ? ' L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1);
    }
    const stem = document.createElementNS(NS, 'path');
    stem.setAttribute('d', d);
    stem.setAttribute('fill', 'none');
    stem.setAttribute('stroke', 'url(#stemGrad)');
    stem.setAttribute('stroke-width', '1.4');
    stem.setAttribute('stroke-linecap', 'round');
    stem.setAttribute('opacity', '.85');
    svg.appendChild(stem);

    // leaves along the stem
    const steps = 17;
    for (let i = 0; i <= steps; i++) {
      const t = i / steps;
      const a = start + (end - start) * t;
      const inner = i % 2 === 0;
      const r = R + (inner ? -9 : 9);

      const [x, y] = toXY(a, r);
      const tangent = a + (side === 1 ? 90 : -90);

      const leaf = document.createElementNS(NS, 'ellipse');
      leaf.setAttribute('cx', x.toFixed(1));
      leaf.setAttribute('cy', y.toFixed(1));
      leaf.setAttribute('rx', inner ? 15 : 13);
      leaf.setAttribute('ry', inner ? 5.4 : 4.8);
      leaf.setAttribute('class', 'leaf');
      leaf.setAttribute('transform',
        `rotate(${(tangent + (inner ? 24 : -24)).toFixed(1)} ${x.toFixed(1)} ${y.toFixed(1)})`);
      leaf.style.animationDelay = (60 + leafIndex * 26) + 'ms';
      svg.appendChild(leaf);
      leafIndex++;
    }
  });

  // small berries at the base
  [[-14, 344], [14, 344]].forEach(([dx, y]) => {
    const berry = document.createElementNS(NS, 'circle');
    berry.setAttribute('cx', cx + dx);
    berry.setAttribute('cy', y);
    berry.setAttribute('r', 4);
    berry.setAttribute('fill', '#c6a15b');
    berry.setAttribute('opacity', '.8');
    svg.appendChild(berry);
  });
})();

/* ---------- Scroll progress ---------- */
(function progress(){
  const bar = document.getElementById('progressBar');
  if (!bar) return;
  const update = () => {
    const h = document.documentElement;
    const max = h.scrollHeight - h.clientHeight;
    bar.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + '%';
  };
  update();
  window.addEventListener('scroll', update, { passive: true });
  window.addEventListener('resize', update);
})();

/* ---------- Reveal on scroll ---------- */
(function reveal(){
  const items = document.querySelectorAll('.reveal');
  if (!('IntersectionObserver' in window)) {
    items.forEach(el => el.classList.add('in'));
    return;
  }
  const groups = new Map();
  items.forEach(el => {
    const key = el.parentElement;
    const arr = groups.get(key) || [];
    arr.push(el);
    groups.set(key, arr);
  });
  groups.forEach(arr => {
    arr.forEach((el, i) => {
      el.style.transitionDelay = Math.min(i * 70, 280) + 'ms';
    });
  });

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in');
        io.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });

  items.forEach(el => io.observe(el));
})();

/* ---------- Active nav link ---------- */
(function activeNav(){
  const links = Array.from(document.querySelectorAll('.site-nav a'));
  const sections = links
    .map(a => document.querySelector(a.getAttribute('href')))
    .filter(Boolean);
  if (!sections.length || !('IntersectionObserver' in window)) return;

  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const id = '#' + entry.target.id;
      links.forEach(a => a.classList.toggle('active', a.getAttribute('href') === id));
    });
  }, { rootMargin: '-45% 0px -50% 0px' });

  sections.forEach(s => io.observe(s));
})();

/* ---------- Mobile nav ---------- */
(function mobileNav(){
  const toggle = document.getElementById('navToggle');
  const nav = document.getElementById('siteNav');
  if (!toggle || !nav) return;

  const close = () => {
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
  };

  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
  });
  nav.querySelectorAll('a').forEach(a => a.addEventListener('click', close));
  document.addEventListener('click', (e) => {
    if (!nav.contains(e.target) && !toggle.contains(e.target)) close();
  });
})();

/* ---------- Timeline filter ---------- */
(function timelineFilter(){
  const buttons = document.querySelectorAll('.filter');
  const items = document.querySelectorAll('.t-item');
  if (!buttons.length) return;

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      buttons.forEach(b => b.classList.toggle('active', b === btn));
      const f = btn.dataset.filter;
      items.forEach(item => {
        const show = f === 'all' || item.dataset.era === f;
        item.classList.toggle('hidden', !show);
      });
    });
  });
})();
